import markdown
from bs4 import BeautifulSoup
import os

from .base import BaseParser


class MarkdownParser(BaseParser):

    def parse(self, file_path: str):

        with open(file_path, "r", encoding="utf-8") as f:
            md_text = f.read()

        html = markdown.markdown(md_text)
        soup = BeautifulSoup(html, "html.parser")

        blocks = []
        full_text = []

        for element in soup.find_all(["h1", "h2", "h3", "p", "li", "code"]):

            text = element.get_text(strip=True)

            if not text:
                continue

            if element.name.startswith("h"):
                block_type = "title"
                level = int(element.name[1])

            elif element.name == "li":
                block_type = "list"
                level = None

            elif element.name == "code":
                block_type = "code"
                level = None

            else:
                block_type = "paragraph"
                level = None

            blocks.append({
                "type": block_type,
                "content": text,
                "metadata": {
                    "level": level
                }
            })

            full_text.append(text)

        return {
            "doc_id": os.path.basename(file_path),
            "text": "\n".join(full_text),
            "blocks": blocks,
            "metadata": {
                "source": file_path
            }
        }